# OliveAnalytics
Advanced Database Management Systems Graduate Project. This project was created using Oracle, io.draw for E-R Logic Diagram, and Java program. We also created a video presentation to explain the features of this application. 
